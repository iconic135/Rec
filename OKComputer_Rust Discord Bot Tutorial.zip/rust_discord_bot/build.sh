#!/bin/bash

# Build script for Discord Bot

set -e

echo "🚀 Building Discord Bot..."

# Check if Rust is installed
if ! command -v cargo &> /dev/null; then
    echo "❌ Cargo is not installed. Please install Rust first."
    exit 1
fi

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "⚠️  No .env file found. Copying from .env.example..."
    cp .env.example .env
    echo "⚠️  Please edit .env with your Discord bot token and application ID!"
fi

# Clean previous builds
echo "🧹 Cleaning previous builds..."
cargo clean

# Build the project
echo "🔨 Building project..."
cargo build --release

# Check if build was successful
if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
    echo "📦 Binary location: target/release/discord_bot"
    echo ""
    echo "To run the bot:"
    echo "1. Edit .env file with your Discord token"
    echo "2. Run: ./target/release/discord_bot"
else
    echo "❌ Build failed!"
    exit 1
fi