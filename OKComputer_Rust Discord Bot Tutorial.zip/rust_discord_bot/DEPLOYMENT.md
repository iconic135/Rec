# Deployment Guide

This guide will help you deploy your Rust Discord bot to various platforms.

## 🚀 Quick Start

### Prerequisites

1. **Rust Installation**
   ```bash
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   source $HOME/.cargo/env
   ```

2. **Discord Bot Setup**
   - Go to [Discord Developer Portal](https://discord.com/developers/applications)
   - Create a new application
   - Go to "Bot" section and create a bot
   - Copy the bot token
   - Go to "OAuth2" section and copy the application ID

### Local Development

1. **Clone and Setup**
   ```bash
   cd rust_discord_bot
   cp .env.example .env
   ```

2. **Configure Environment**
   Edit `.env` file:
   ```
   DISCORD_TOKEN=your_bot_token_here
   APPLICATION_ID=your_application_id_here
   RUST_LOG=info
   ```

3. **Run the Bot**
   ```bash
   cargo run --release
   ```

## 📦 Production Deployment

### Option 1: Systemd Service (Linux)

1. **Build the binary**
   ```bash
   cargo build --release
   sudo cp target/release/discord_bot /usr/local/bin/
   ```

2. **Create systemd service file**
   ```bash
   sudo nano /etc/systemd/system/discord-bot.service
   ```

   Add this content:
   ```ini
   [Unit]
   Description=Discord Bot
   After=network.target

   [Service]
   Type=simple
   User=your_username
   WorkingDirectory=/path/to/your/bot
   Environment="DISCORD_TOKEN=your_bot_token_here"
   Environment="APPLICATION_ID=your_application_id_here"
   Environment="RUST_LOG=info"
   ExecStart=/usr/local/bin/discord_bot
   Restart=always
   RestartSec=10

   [Install]
   WantedBy=multi-user.target
   ```

3. **Enable and start the service**
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable discord-bot
   sudo systemctl start discord-bot
   ```

4. **Check status**
   ```bash
   sudo systemctl status discord-bot
   sudo journalctl -u discord-bot -f
   ```

### Option 2: PM2 (Node.js Process Manager)

1. **Install PM2**
   ```bash
   npm install -g pm2
   ```

2. **Create ecosystem file**
   ```javascript
   // ecosystem.config.js
   module.exports = {
     apps: [{
       name: 'discord-bot',
       script: 'target/release/discord_bot',
       env: {
         DISCORD_TOKEN: 'your_bot_token_here',
         APPLICATION_ID: 'your_application_id_here',
         RUST_LOG: 'info'
       },
       restart_delay: 10000,
       max_restarts: 10,
       min_uptime: '10s'
     }]
   };
   ```

3. **Start with PM2**
   ```bash
   pm2 start ecosystem.config.js
   pm2 save
   pm2 startup
   ```

### Option 3: Docker (Recommended)

1. **Create Dockerfile**
   ```dockerfile
   FROM rust:1.70 as builder
   WORKDIR /app
   COPY . .
   RUN cargo build --release

   FROM debian:bullseye-slim
   RUN apt-get update && apt-get install -y \
       ca-certificates \
       && rm -rf /var/lib/apt/lists/*
   WORKDIR /app
   COPY --from=builder /app/target/release/discord_bot /app/discord_bot
   COPY --from=builder /app/.env.example /app/.env
   CMD ["/app/discord_bot"]
   ```

2. **Build and run**
   ```bash
   docker build -t discord-bot .
   docker run -d \
     --name discord-bot \
     --env DISCORD_TOKEN=your_bot_token_here \
     --env APPLICATION_ID=your_application_id_here \
     --restart unless-stopped \
     discord-bot
   ```

### Option 4: Heroku

1. **Create Heroku app**
   ```bash
   heroku create your-bot-name
   heroku buildpacks:clear
   heroku buildpacks:add emk/rust
   ```

2. **Configure environment variables**
   ```bash
   heroku config:set DISCORD_TOKEN=your_bot_token_here
   heroku config:set APPLICATION_ID=your_application_id_here
   heroku config:set RUST_LOG=info
   ```

3. **Deploy**
   ```bash
   git push heroku main
   ```

### Option 5: Railway

1. **Connect your GitHub repository to Railway**
2. **Configure environment variables** in Railway dashboard
3. **Deploy automatically on push**

### Option 6: DigitalOcean App Platform

1. **Create app from GitHub repository**
2. **Configure environment variables**
3. **Deploy**

## 🔧 Configuration

### Environment Variables

All configuration is done through environment variables:

| Variable | Description | Default |
|----------|-------------|---------|
| `DISCORD_TOKEN` | Your Discord bot token | Required |
| `APPLICATION_ID` | Your Discord application ID | Required |
| `DATABASE_URL` | SQLite database path | `sqlite:./bot_data.db` |
| `RUST_LOG` | Logging level | `info` |
| `BOT_PREFIX` | Traditional command prefix | `!` |

### Features

You can enable/disable features by modifying `Cargo.toml`:

```toml
[features]
default = ["music", "database"]  # Enable music and database support
music = ["songbird"]              # Music/voice support
database = ["sqlx"]               # Database support
```

## 📊 Monitoring

### Logs

- **Systemd**: `sudo journalctl -u discord-bot -f`
- **PM2**: `pm2 logs discord-bot`
- **Docker**: `docker logs -f discord-bot`

### Health Checks

Add a health check endpoint if needed:

```rust
// In your main.rs or a separate health module
async fn health_check() -> Result<(), Box<dyn std::error::Error>> {
    // Check database connection, Discord API, etc.
    Ok(())
}
```

## 🔄 Updates

### Automatic Updates (Systemd)

1. **Create update script**
   ```bash
   #!/bin/bash
   # update-bot.sh
   cd /path/to/rust_discord_bot
   git pull origin main
   cargo build --release
   sudo systemctl restart discord-bot
   ```

2. **Add cron job**
   ```bash
   crontab -e
   # Add: 0 2 * * * /path/to/update-bot.sh
   ```

### Manual Updates

```bash
# Pull latest changes
git pull origin main

# Rebuild
cargo build --release

# Restart service (if using systemd)
sudo systemctl restart discord-bot

# Or restart PM2
pm2 restart discord-bot

# Or restart Docker
docker restart discord-bot
```

## 🛡️ Security

1. **Keep your bot token secure**
   - Never commit it to version control
   - Use environment variables
   - Rotate tokens periodically

2. **Use HTTPS for webhooks** (if applicable)

3. **Limit bot permissions** to only what's needed

4. **Regular security updates**
   ```bash
   cargo update
   cargo audit
   ```

## 📈 Performance

1. **Use release builds** for production
   ```bash
   cargo build --release
   ```

2. **Optimize for size** (if needed)
   ```toml
   [profile.release]
   opt-level = "z"     # Optimize for size
   lto = true          # Enable Link Time Optimization
   codegen-units = 1   # Single codegen unit for better optimization
   ```

3. **Monitor resource usage**
   - CPU: `top` or `htop`
   - Memory: `free -h`
   - Disk: `df -h`

## 🚨 Troubleshooting

### Common Issues

1. **"Invalid token" error**
   - Check your `DISCORD_TOKEN` environment variable
   - Ensure the token is correct and not expired

2. **"Missing permissions" error**
   - Check bot permissions in Discord server settings
   - Ensure the bot has the required permissions for commands

3. **"Command not registered" error**
   - Commands are registered when the bot starts
   - It may take up to 1 hour for global commands to propagate
   - Use guild-specific commands for faster testing

4. **Database connection errors**
   - Ensure the database file has correct permissions
   - Check the `DATABASE_URL` format

5. **Memory issues**
   - Monitor memory usage with system tools
   - Check for memory leaks in custom code
   - Consider using a memory profiler

### Debug Mode

Run with debug logging:
```bash
RUST_LOG=debug cargo run
```

### Getting Help

1. Check the logs for error messages
2. Review the troubleshooting section in this guide
3. Check existing issues in the repository
4. Create a new issue with detailed information

## 🎯 Best Practices

1. **Use environment variables** for all configuration
2. **Log important events** for debugging
3. **Handle errors gracefully**
4. **Test thoroughly** before deploying
5. **Monitor your bot** in production
6. **Keep dependencies updated**
7. **Use proper error handling** with `Result` types
8. **Implement rate limiting** for API calls
9. **Use connection pooling** for databases
10. **Implement proper shutdown handling**

## 📚 Additional Resources

- [Serenity Documentation](https://docs.rs/serenity)
- [Discord API Documentation](https://discord.com/developers/docs)
- [Rust Book](https://doc.rust-lang.org/book/)
- [Systemd Service Documentation](https://www.freedesktop.org/software/systemd/man/systemd.service.html)