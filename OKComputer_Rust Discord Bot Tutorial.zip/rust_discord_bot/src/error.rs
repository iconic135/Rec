use thiserror::Error;

#[derive(Debug, Error)]
pub enum BotError {
    #[error("Discord API error: {0}")]
    Discord(#[from] serenity::Error),
    
    #[error("Database error: {0}")]
    Database(#[from] sqlx::Error),
    
    #[error("HTTP error: {0}")]
    Http(#[from] reqwest::Error),
    
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    
    #[error("JSON serialization error: {0}")]
    Json(#[from] serde_json::Error),
    
    #[error("Configuration error: {0}")]
    Config(#[from] anyhow::Error),
    
    #[error("Voice connection error: {0}")]
    Voice(String),
    
    #[error("Command error: {0}")]
    Command(String),
    
    #[error("Permission error: {0}")]
    Permission(String),
}

impl BotError {
    pub fn user_friendly(&self) -> String {
        match self {
            BotError::Discord(_) => "Discord API error occurred".to_string(),
            BotError::Database(_) => "Database error occurred".to_string(),
            BotError::Http(_) => "Network error occurred".to_string(),
            BotError::Io(_) => "File system error occurred".to_string(),
            BotError::Json(_) => "Data processing error occurred".to_string(),
            BotError::Config(_) => "Configuration error occurred".to_string(),
            BotError::Voice(msg) => format!("Voice error: {}", msg),
            BotError::Command(msg) => format!("Command error: {}", msg),
            BotError::Permission(msg) => format!("Permission error: {}", msg),
        }
    }
}

pub type BotResult<T> = Result<T, BotError>;