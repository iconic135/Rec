use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::env;
use std::fs;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    pub discord_token: String,
    pub application_id: u64,
    pub bot_prefix: String,
    pub database_url: String,
    pub log_level: String,
}

impl Config {
    pub fn load(config_file: &str) -> Result<Self> {
        // Try to load from environment first, then config file
        let config = if std::path::Path::new(config_file).exists() {
            let content = fs::read_to_string(config_file)?;
            serde_json::from_str(&content)?
        } else {
            Config::from_env()?
        };

        Ok(config)
    }

    pub fn from_env() -> Result<Self> {
        Ok(Config {
            discord_token: env::var("DISCORD_TOKEN")
                .expect("Expected DISCORD_TOKEN in environment variables"),
            application_id: env::var("APPLICATION_ID")
                .expect("Expected APPLICATION_ID in environment variables")
                .parse()
                .expect("APPLICATION_ID must be a valid integer"),
            bot_prefix: env::var("BOT_PREFIX").unwrap_or_else(|_| "!".to_string()),
            database_url: env::var("DATABASE_URL")
                .unwrap_or_else(|_| "sqlite:./bot_data.db".to_string()),
            log_level: env::var("RUST_LOG").unwrap_or_else(|_| "info".to_string()),
        })
    }
}

impl Default for Config {
    fn default() -> Self {
        Self {
            discord_token: String::new(),
            application_id: 0,
            bot_prefix: "!".to_string(),
            database_url: "sqlite:./bot_data.db".to_string(),
            log_level: "info".to_string(),
        }
    }
}