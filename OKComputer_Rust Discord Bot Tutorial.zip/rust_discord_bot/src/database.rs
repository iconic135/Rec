use crate::error::BotResult;
use sqlx::sqlite::SqlitePoolOptions;
use sqlx::SqlitePool;

pub struct Database {
    pool: SqlitePool,
}

impl Database {
    pub async fn new(database_url: &str) -> BotResult<Self> {
        let pool = SqlitePoolOptions::new()
            .connect(database_url)
            .await
            .map_err(|e| crate::error::BotError::Database(e))?;
        
        Ok(Self { pool })
    }
    
    pub async fn init_tables(&self) -> BotResult<()> {
        // Create tables if they don't exist
        sqlx::query(
            r#"
            CREATE TABLE IF NOT EXISTS guild_settings (
                guild_id INTEGER PRIMARY KEY,
                prefix TEXT DEFAULT '!',
                welcome_channel_id INTEGER,
                log_channel_id INTEGER,
                auto_role_id INTEGER
            )
            "#,
        )
        .execute(&self.pool)
        .await
        .map_err(|e| crate::error::BotError::Database(e))?;
        
        sqlx::query(
            r#"
            CREATE TABLE IF NOT EXISTS reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                guild_id INTEGER,
                channel_id INTEGER,
                message TEXT NOT NULL,
                trigger_at TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            "#,
        )
        .execute(&self.pool)
        .await
        .map_err(|e| crate::error::BotError::Database(e))?;
        
        sqlx::query(
            r#"
            CREATE TABLE IF NOT EXISTS timers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                guild_id INTEGER,
                channel_id INTEGER,
                message TEXT NOT NULL,
                duration_seconds INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            "#,
        )
        .execute(&self.pool)
        .await
        .map_err(|e| crate::error::BotError::Database(e))?;
        
        Ok(())
    }
    
    pub async fn get_guild_prefix(&self, guild_id: u64) -> BotResult<Option<String>> {
        let prefix: Option<String> = sqlx::query_scalar(
            "SELECT prefix FROM guild_settings WHERE guild_id = ?"
        )
        .bind(guild_id as i64)
        .fetch_optional(&self.pool)
        .await
        .map_err(|e| crate::error::BotError::Database(e))?;
        
        Ok(prefix)
    }
    
    pub async fn set_guild_prefix(&self, guild_id: u64, prefix: &str) -> BotResult<()> {
        sqlx::query(
            "INSERT OR REPLACE INTO guild_settings (guild_id, prefix) VALUES (?, ?)"
        )
        .bind(guild_id as i64)
        .bind(prefix)
        .execute(&self.pool)
        .await
        .map_err(|e| crate::error::BotError::Database(e))?;
        
        Ok(())
    }
}

#[cfg(feature = "database")]
pub async fn init(database_url: &str) -> BotResult<()> {
    let db = Database::new(database_url).await?;
    db.init_tables().await?;
    Ok(())
}

#[cfg(not(feature = "database"))]
pub async fn init(_database_url: &str) -> BotResult<()> {
    Ok(())
}