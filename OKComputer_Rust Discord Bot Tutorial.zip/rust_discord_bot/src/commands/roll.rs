use crate::commands::CommandResult;
use rand::Rng;
use serenity::builder::CreateApplicationCommand;
use serenity::model::application::interaction::application_command::CommandDataOption;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("roll")
        .description("Roll a dice")
        .create_option(|option| {
            option
                .name("sides")
                .description("Number of sides on the dice (default: 6)")
                .kind(serenity::model::application::command::CommandOptionType::Integer)
                .min_int_value(2)
                .max_int_value(100)
                .required(false)
        })
        .create_option(|option| {
            option
                .name("dice")
                .description("Number of dice to roll (default: 1)")
                .kind(serenity::model::application::command::CommandOptionType::Integer)
                .min_int_value(1)
                .max_int_value(10)
                .required(false)
        })
}

pub fn run(options: &[CommandDataOption]) -> CommandResult {
    let sides = super::get_integer_option(options, "sides").unwrap_or(6) as u32;
    let dice = super::get_integer_option(options, "dice").unwrap_or(1) as u32;
    
    let mut rng = rand::thread_rng();
    let mut results = Vec::new();
    let mut total = 0;
    
    for i in 1..=dice {
        let roll = rng.gen_range(1..=sides);
        results.push(roll);
        total += roll;
    }
    
    let mut response = format!("🎲 Rolling {}d{}...\n", dice, sides);
    
    if dice == 1 {
        response.push_str(&format!("Result: **{}**", results[0]));
    } else {
        response.push_str("Results: ");
        for (i, result) in results.iter().enumerate() {
            if i > 0 {
                response.push_str(", ");
            }
            response.push_str(&format!("**{}**", result));
        }
        response.push_str(&format!("\nTotal: **{}**", total));
    }
    
    Ok(response)
}