use crate::commands::CommandResult;
use crate::error::BotError;
use serenity::builder::CreateApplicationCommand;
use serenity::client::Context;
use serenity::model::application::interaction::application_command::CommandDataOption;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command.name("serverinfo").description("Get information about the server")
}

pub async fn run(ctx: &Context, _options: &[CommandDataOption]) -> CommandResult {
    let guild_id = ctx.cache.guilds().first()
        .ok_or_else(|| BotError::Command("This command can only be used in a server".to_string()))?;
    
    let guild = guild_id
        .to_partial_guild(&ctx.http)
        .await
        .map_err(|_| BotError::Command("Failed to get server info".to_string()))?;

    let mut response = String::new();
    
    // Server name and icon
    response.push_str(&format!("🏠 **Server:** {}\n", guild.name));
    response.push_str(&format!("🆔 **Server ID:** {}\n", guild.id));
    
    // Server creation date
    let created_at = guild.id.created_at().format("%B %d, %Y at %H:%M UTC");
    response.push_str(&format!("📅 **Created:** {}\n", created_at));
    
    // Owner
    if let Some(owner_id) = guild.owner_id {
        response.push_str(&format!("👑 **Owner:** <@{}>\n", owner_id));
    }
    
    // Member counts
    if let Some(member_count) = guild.member_count {
        response.push_str(&format!("👥 **Members:** {}\n", member_count));
    }
    
    // Channel counts
    let channels = guild_id.channels(&ctx.http).await
        .map_err(|_| BotError::Command("Failed to get channel info".to_string()))?;
    
    let text_channels = channels.values().filter(|c| c.kind == serenity::model::channel::ChannelType::Text).count();
    let voice_channels = channels.values().filter(|c| c.kind == serenity::model::channel::ChannelType::Voice).count();
    
    response.push_str(&format!("💬 **Text Channels:** {}\n", text_channels));
    response.push_str(&format!("🔊 **Voice Channels:** {}\n", voice_channels));
    
    // Role count
    let roles = guild_id.roles(&ctx.http).await
        .map_err(|_| BotError::Command("Failed to get role info".to_string()))?;
    response.push_str(&format!("🎭 **Roles:** {}\n", roles.len()));
    
    // Boost level
    if let Some(boost_level) = guild.premium_tier {
        response.push_str(&format!("💎 **Boost Level:** {}\n", boost_level as u8));
    }
    
    // Boost count
    if let Some(boost_count) = guild.premium_subscription_count {
        response.push_str(&format!("⚡ **Boosts:** {}\n", boost_count));
    }
    
    // Verification level
    response.push_str(&format!("🛡️ **Verification Level:** {:?}\n", guild.verification_level));
    
    // Server icon
    if let Some(icon_url) = guild.icon_url() {
        response.push_str(&format!("\n🖼️ **Server Icon:** {}\n", icon_url));
    }

    Ok(response)
}