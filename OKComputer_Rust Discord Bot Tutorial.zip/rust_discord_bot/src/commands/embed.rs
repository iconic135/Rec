use crate::commands::CommandResult;
use crate::error::BotError;
use serenity::builder::CreateApplicationCommand;
use serenity::model::application::interaction::application_command::CommandDataOption;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("embed")
        .description("Create a custom embed message")
        .create_option(|option| {
            option
                .name("title")
                .description("Embed title")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(true)
        })
        .create_option(|option| {
            option
                .name("description")
                .description("Embed description")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(true)
        })
        .create_option(|option| {
            option
                .name("color")
                .description("Embed color (hex color code, e.g., #FF0000)")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(false)
        })
}

pub fn run(options: &[CommandDataOption]) -> CommandResult {
    let title = super::get_string_option(options, "title")
        .ok_or_else(|| BotError::Command("Title is required".to_string()))?;
    
    let description = super::get_string_option(options, "description")
        .ok_or_else(|| BotError::Command("Description is required".to_string()))?;
    
    let color_str = super::get_string_option(options, "color");
    
    // Note: This is a simplified version - in a real bot you'd use serenity's embed builder
    // Since we can't easily create embeds in response content, we'll format it nicely
    
    let mut response = String::new();
    response.push_str("📄 **Custom Embed**\n\n");
    response.push_str(&format!("**{}**\n\n", title));
    response.push_str(&description);
    
    if let Some(color) = color_str {
        response.push_str(&format!("\n\n🎨 **Color:** {}", color));
    }
    
    Ok(response)
}