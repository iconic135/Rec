use crate::commands::CommandResult;
use crate::error::BotError;
use serenity::builder::CreateApplicationCommand;
use serenity::model::application::interaction::application_command::CommandDataOption;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("say")
        .description("Make the bot say something")
        .create_option(|option| {
            option
                .name("message")
                .description("Message to send")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(true)
        })
}

pub fn run(options: &[CommandDataOption]) -> CommandResult {
    let message = super::get_string_option(options, "message")
        .ok_or_else(|| BotError::Command("Message is required".to_string()))?;
    
    // Simply return the message - the bot will say it
    Ok(message)
}