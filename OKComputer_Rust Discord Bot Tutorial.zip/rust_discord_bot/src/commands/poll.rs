use crate::commands::CommandResult;
use serenity::builder::CreateApplicationCommand;
use serenity::model::application::interaction::application_command::CommandDataOption;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("poll")
        .description("Create a poll")
        .create_option(|option| {
            option
                .name("question")
                .description("The poll question")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(true)
        })
        .create_option(|option| {
            option
                .name("option1")
                .description("First option")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(true)
        })
        .create_option(|option| {
            option
                .name("option2")
                .description("Second option")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(true)
        })
        .create_option(|option| {
            option
                .name("option3")
                .description("Third option (optional)")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(false)
        })
        .create_option(|option| {
            option
                .name("option4")
                .description("Fourth option (optional)")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(false)
        })
        .create_option(|option| {
            option
                .name("option5")
                .description("Fifth option (optional)")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(false)
        })
}

pub fn run(options: &[CommandDataOption]) -> CommandResult {
    let question = super::get_string_option(options, "question")
        .ok_or_else(|| super::super::error::BotError::Command("Question is required".to_string()))?;
    
    let option1 = super::get_string_option(options, "option1")
        .ok_or_else(|| super::super::error::BotError::Command("At least 2 options are required".to_string()))?;
    
    let option2 = super::get_string_option(options, "option2")
        .ok_or_else(|| super::super::error::BotError::Command("At least 2 options are required".to_string()))?;
    
    let option3 = super::get_string_option(options, "option3");
    let option4 = super::get_string_option(options, "option4");
    let option5 = super::get_string_option(options, "option5");
    
    let mut response = String::new();
    response.push_str("📊 **Poll**\n\n");
    response.push_str(&format!("**Question:** {}\n\n", question));
    
    response.push_str("1️⃣ ");
    response.push_str(&option1);
    response.push_str("\n");
    
    response.push_str("2️⃣ ");
    response.push_str(&option2);
    response.push_str("\n");
    
    if let Some(opt3) = option3 {
        response.push_str("3️⃣ ");
        response.push_str(&opt3);
        response.push_str("\n");
    }
    
    if let Some(opt4) = option4 {
        response.push_str("4️⃣ ");
        response.push_str(&opt4);
        response.push_str("\n");
    }
    
    if let Some(opt5) = option5 {
        response.push_str("5️⃣ ");
        response.push_str(&opt5);
        response.push_str("\n");
    }
    
    response.push_str("\nReact with the corresponding emoji to vote!");
    
    Ok(response)
}