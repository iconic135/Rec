use crate::commands::CommandResult;
use crate::error::BotError;
use serde::Deserialize;

#[derive(Deserialize)]
struct CatResponse {
    url: String,
}

pub async fn run() -> CommandResult {
    let response = reqwest::get("https://api.thecatapi.com/v1/images/search")
        .await
        .map_err(|_| BotError::Command("Failed to fetch cat image".to_string()))?;
    
    let cat_data: Vec<CatResponse> = response
        .json()
        .await
        .map_err(|_| BotError::Command("Failed to parse cat image data".to_string()))?;
    
    if let Some(cat) = cat_data.first() {
        Ok(format!("🐱 Random cat: {}", cat.url))
    } else {
        Err(BotError::Command("No cat image found".to_string()))
    }
}