use crate::commands::CommandResult;
use crate::error::BotError;
use serde::Deserialize;

#[derive(Deserialize)]
struct MemeResponse {
    url: String,
    title: String,
}

pub async fn run() -> CommandResult {
    let response = reqwest::get("https://meme-api.com/gimme")
        .await
        .map_err(|_| BotError::Command("Failed to fetch meme".to_string()))?;
    
    let meme_data: MemeResponse = response
        .json()
        .await
        .map_err(|_| BotError::Command("Failed to parse meme data".to_string()))?;
    
    Ok(format!("😂 **{}**\n{}", meme_data.title, meme_data.url))
}