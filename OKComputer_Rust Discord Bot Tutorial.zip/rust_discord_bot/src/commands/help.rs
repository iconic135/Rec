use crate::commands::CommandResult;
use serenity::builder::CreateApplicationCommand;
use serenity::model::application::interaction::application_command::CommandDataOption;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("help")
        .description("Get help and see all available commands")
        .create_option(|option| {
            option
                .name("command")
                .description("Specific command to get help for")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(false)
        })
}

pub fn run(options: &[CommandDataOption]) -> CommandResult {
    let command_name = super::get_string_option(options, "command");
    
    if let Some(cmd) = command_name {
        match cmd.as_str() {
            "ping" => Ok("**Ping Command**\nUsage: `/ping`\nDescription: Check bot latency and response time.".to_string()),
            "info" => Ok("**Info Command**\nUsage: `/info`\nDescription: Get information about the bot.".to_string()),
            "help" => Ok("**Help Command**\nUsage: `/help [command]`\nDescription: Get help for all commands or a specific command.".to_string()),
            "userinfo" => Ok("**User Info Command**\nUsage: `/userinfo [user]`\nDescription: Get information about a user (or yourself if no user specified).".to_string()),
            "serverinfo" => Ok("**Server Info Command**\nUsage: `/serverinfo`\nDescription: Get information about the current server.".to_string()),
            "avatar" => Ok("**Avatar Command**\nUsage: `/avatar [user]`\nDescription: Get a user's avatar (or your own if no user specified).".to_string()),
            "roll" => Ok("**Roll Command**\nUsage: `/roll [sides]`\nDescription: Roll a dice with specified number of sides (default: 6).".to_string()),
            "choose" => Ok("**Choose Command**\nUsage: `/choose [options]`\nDescription: Randomly choose from given options.".to_string()),
            "poll" => Ok("**Poll Command**\nUsage: `/poll question option1 option2 [option3]...`\nDescription: Create a poll with up to 10 options.".to_string()),
            "kick" => Ok("**Kick Command**\nUsage: `/kick user reason`\nDescription: Kick a user from the server (requires kick permissions).".to_string()),
            "ban" => Ok("**Ban Command**\nUsage: `/ban user reason`\nDescription: Ban a user from the server (requires ban permissions).".to_string()),
            "clear" => Ok("**Clear Command**\nUsage: `/clear amount`\nDescription: Clear specified number of messages (requires manage messages).".to_string()),
            "slowmode" => Ok("**Slowmode Command**\nUsage: `/slowmode seconds`\nDescription: Set slowmode for the channel (requires manage channels).".to_string()),
            "mute" => Ok("**Mute Command**\nUsage: `/mute user reason`\nDescription: Mute a user (requires mute permissions).".to_string()),
            "unmute" => Ok("**Unmute Command**\nUsage: `/unmute user`\nDescription: Unmute a user (requires mute permissions).".to_string()),
            "weather" => Ok("**Weather Command**\nUsage: `/weather city`\nDescription: Get current weather for a city.".to_string()),
            "cat" => Ok("**Cat Command**\nUsage: `/cat`\nDescription: Get a random cat picture.".to_string()),
            "dog" => Ok("**Dog Command**\nUsage: `/dog`\nDescription: Get a random dog picture.".to_string()),
            "meme" => Ok("**Meme Command**\nUsage: `/meme`\nDescription: Get a random meme.".to_string()),
            "reminder" => Ok("**Reminder Command**\nUsage: `/reminder time message`\nDescription: Set a reminder. Time format: 1h30m, 2d, etc.".to_string()),
            "timer" => Ok("**Timer Command**\nUsage: `/timer seconds`\nDescription: Set a timer for specified seconds.".to_string()),
            "embed" => Ok("**Embed Command**\nUsage: `/embed title description color`\nDescription: Create a custom embed message.".to_string()),
            "say" => Ok("**Say Command**\nUsage: `/say message`\nDescription: Make the bot say something.".to_string()),
            _ => Ok("Command not found. Use `/help` to see all available commands.".to_string()),
        }
    } else {
        let help_message = "📚 **Bot Commands Help**\n\n";
        
        let utility = "**🔧 Utility Commands:**\n";
        let utility_cmds = "`/ping` - Check bot latency\n`/info` - Bot information\n`/help` - This help message\n`/userinfo` - User information\n`/serverinfo` - Server information\n`/avatar` - Get user avatar\n";
        
        let fun = "**🎲 Fun Commands:**\n";
        let fun_cmds = "`/roll` - Roll dice\n`/choose` - Random choice\n`/poll` - Create poll\n`/cat` - Random cat picture\n`/dog` - Random dog picture\n`/meme` - Random meme\n";
        
        let moderation = "**🛡️ Moderation Commands:**\n";
        let mod_cmds = "`/kick` - Kick user\n`/ban` - Ban user\n`/clear` - Clear messages\n`/slowmode` - Set slowmode\n`/mute` - Mute user\n`/unmute` - Unmute user\n";
        
        let tools = "**🛠️ Tools:**\n";
        let tool_cmds = "`/weather` - Weather info\n`/reminder` - Set reminder\n`/timer` - Set timer\n`/embed` - Create embed\n`/say` - Bot says message\n";
        
        let note = "\n💡 **Tip:** Use `/help command_name` for detailed info about a specific command.";
        
        Ok(format!(
            "{}{}{}{}{}{}{}{}{}",
            help_message, utility, utility_cmds, fun, fun_cmds, moderation, mod_cmds, tools, tool_cmds, note
        ))
    }
}