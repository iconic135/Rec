use crate::commands::CommandResult;
use rand::seq::SliceRandom;
use rand::thread_rng;
use serenity::builder::CreateApplicationCommand;
use serenity::model::application::interaction::application_command::CommandDataOption;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("choose")
        .description("Randomly choose from given options")
        .create_option(|option| {
            option
                .name("options")
                .description("Comma-separated options to choose from")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(true)
        })
}

pub fn run(options: &[CommandDataOption]) -> CommandResult {
    let options_str = super::get_string_option(options, "options")
        .ok_or_else(|| super::super::error::BotError::Command("Options are required".to_string()))?;
    
    let choices: Vec<&str> = options_str.split(',').map(|s| s.trim()).collect();
    
    if choices.is_empty() {
        return Err(super::super::error::BotError::Command("Please provide at least one option".to_string()));
    }
    
    if choices.len() == 1 {
        return Ok(format!("🤔 There's only one option: **{}**", choices[0]));
    }
    
    let mut rng = thread_rng();
    let choice = choices.choose(&mut rng)
        .ok_or_else(|| super::super::error::BotError::Command("Failed to make a choice".to_string()))?;
    
    Ok(format!("🎲 I choose: **{}**", choice))
}