use crate::commands::CommandResult;
use crate::error::BotError;
use serde::Deserialize;

#[derive(Deserialize)]
struct DogResponse {
    url: String,
}

pub async fn run() -> CommandResult {
    let response = reqwest::get("https://api.thedogapi.com/v1/images/search")
        .await
        .map_err(|_| BotError::Command("Failed to fetch dog image".to_string()))?;
    
    let dog_data: Vec<DogResponse> = response
        .json()
        .await
        .map_err(|_| BotError::Command("Failed to parse dog image data".to_string()))?;
    
    if let Some(dog) = dog_data.first() {
        Ok(format!("🐶 Random dog: {}", dog.url))
    } else {
        Err(BotError::Command("No dog image found".to_string()))
    }
}