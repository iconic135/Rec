use crate::commands::CommandResult;
use crate::error::BotError;
use serenity::builder::CreateApplicationCommand;
use serenity::model::application::interaction::application_command::CommandDataOption;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("reminder")
        .description("Set a reminder")
        .create_option(|option| {
            option
                .name("time")
                .description("Time until reminder (e.g., 1h30m, 2d, 30m)")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(true)
        })
        .create_option(|option| {
            option
                .name("message")
                .description("Reminder message")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(true)
        })
}

pub async fn run(options: &[CommandDataOption]) -> CommandResult {
    let time_str = super::get_string_option(options, "time")
        .ok_or_else(|| BotError::Command("Time is required".to_string()))?;
    
    let message = super::get_string_option(options, "message")
        .ok_or_else(|| BotError::Command("Message is required".to_string()))?;
    
    // Parse time string (e.g., "1h30m", "2d", "30m")
    let total_seconds = parse_time_string(&time_str)?;
    
    if total_seconds == 0 {
        return Err(BotError::Command("Time must be greater than 0".to_string()));
    }
    
    // In a real implementation, you would store this reminder in a database
    // and have a background task to check and send reminders
    // For now, we'll just acknowledge the reminder
    
    let hours = total_seconds / 3600;
    let minutes = (total_seconds % 3600) / 60;
    let seconds = total_seconds % 60;
    
    let mut time_display = String::new();
    if hours > 0 {
        time_display.push_str(&format!("{}h ", hours));
    }
    if minutes > 0 {
        time_display.push_str(&format!("{}m ", minutes));
    }
    if seconds > 0 {
        time_display.push_str(&format!("{}s", seconds));
    }
    
    Ok(format!(
        "⏰ **Reminder Set**\n\n**Time:** {}\n**Message:** {}\n\n💡 Note: This is a demo implementation. In a full bot, you'd receive a DM when the time is up.",
        time_display.trim(), message
    ))
}

fn parse_time_string(time_str: &str) -> Result<u64, BotError> {
    let mut total_seconds = 0u64;
    let mut current_number = String::new();
    
    for ch in time_str.chars() {
        if ch.is_numeric() {
            current_number.push(ch);
        } else {
            let number = current_number.parse::<u64>()
                .map_err(|_| BotError::Command("Invalid time format".to_string()))?;
            
            match ch {
                's' | 'S' => total_seconds += number,
                'm' | 'M' => total_seconds += number * 60,
                'h' | 'H' => total_seconds += number * 3600,
                'd' | 'D' => total_seconds += number * 86400,
                _ => return Err(BotError::Command("Invalid time unit. Use s, m, h, or d".to_string())),
            }
            
            current_number.clear();
        }
    }
    
    if !current_number.is_empty() {
        return Err(BotError::Command("Time must end with a unit (s, m, h, d)".to_string()));
    }
    
    Ok(total_seconds)
}