use crate::commands::CommandResult;
use serenity::builder::CreateApplicationCommand;
use serenity::model::application::interaction::application_command::CommandDataOption;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command.name("info").description("Get information about the bot")
}

pub fn run(_options: &[CommandDataOption]) -> CommandResult {
    let info = "🤖 **Bot Information**\n\n";
    let features = "**Features:**\n";
    let feature_list = "• Moderation commands\n• Utility commands\n• Fun commands\n• Information commands\n• Music support (coming soon)\n";
    let invite = "\n**Invite me to your server!**\nUse the invite link in my profile.";
    
    Ok(format!("{}{}{}{}", info, features, feature_list, invite))
}