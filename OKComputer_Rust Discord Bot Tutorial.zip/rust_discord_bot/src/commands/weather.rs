use crate::commands::CommandResult;
use crate::error::BotError;
use serenity::builder::CreateApplicationCommand;
use serenity::model::application::interaction::application_command::CommandDataOption;
use serde::Deserialize;

#[derive(Deserialize)]
struct WeatherResponse {
    name: String,
    main: MainWeather,
    weather: Vec<Weather>,
    wind: Wind,
}

#[derive(Deserialize)]
struct MainWeather {
    temp: f64,
    feels_like: f64,
    humidity: u32,
}

#[derive(Deserialize)]
struct Weather {
    description: String,
    main: String,
}

#[derive(Deserialize)]
struct Wind {
    speed: f64,
}

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("weather")
        .description("Get current weather for a city")
        .create_option(|option| {
            option
                .name("city")
                .description("City name")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(true)
        })
}

pub async fn run(options: &[CommandDataOption]) -> CommandResult {
    let city = super::get_string_option(options, "city")
        .ok_or_else(|| BotError::Command("City name is required".to_string()))?;
    
    // Note: In a real bot, you should use your own OpenWeatherMap API key
    // This is a placeholder - you'll need to sign up at openweathermap.org
    let api_key = std::env::var("WEATHER_API_KEY").unwrap_or_else(|_| "your_api_key_here".to_string());
    
    let url = format!(
        "https://api.openweathermap.org/data/2.5/weather?q={}&appid={}&units=metric",
        city, api_key
    );
    
    let response = reqwest::get(&url)
        .await
        .map_err(|_| BotError::Command("Failed to fetch weather data".to_string()))?;
    
    if !response.status().is_success() {
        return Err(BotError::Command("City not found or API error".to_string()));
    }
    
    let weather_data: WeatherResponse = response
        .json()
        .await
        .map_err(|_| BotError::Command("Failed to parse weather data".to_string()))?;
    
    let description = weather_data.weather.first()
        .map(|w| w.description.clone())
        .unwrap_or_else(|| "Unknown".to_string());
    
    let mut response = String::new();
    response.push_str(&format!("🌤️ **Weather in {}**\n\n", weather_data.name));
    response.push_str(&format!("🌡️ **Temperature:** {:.1}°C\n", weather_data.main.temp));
    response.push_str(&format!("🤔 **Feels Like:** {:.1}°C\n", weather_data.main.feels_like));
    response.push_str(&format!("💧 **Humidity:** {}%\n", weather_data.main.humidity));
    response.push_str(&format!("💨 **Wind Speed:** {:.1} m/s\n", weather_data.wind.speed));
    response.push_str(&format!("☁️ **Condition:** {}\n", description));
    
    Ok(response)
}