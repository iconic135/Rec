use crate::commands::CommandResult;
use serenity::builder::CreateApplicationCommand;
use serenity::model::application::interaction::application_command::CommandDataOption;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command.name("ping").description("Get bot latency and response time")
}

pub fn run(_options: &[CommandDataOption]) -> CommandResult {
    Ok("🏓 Pong! Bot is responding normally.".to_string())
}