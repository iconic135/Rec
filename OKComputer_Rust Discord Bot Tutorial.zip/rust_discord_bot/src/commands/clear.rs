use crate::commands::{check_bot_permission, check_permission, CommandResult, ERROR_GUILD_ONLY, ERROR_NO_PERMISSION};
use crate::error::BotError;
use serenity::builder::CreateApplicationCommand;
use serenity::client::Context;
use serenity::model::application::interaction::application_command::CommandDataOption;
use serenity::model::permissions::Permissions;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("clear")
        .description("Clear messages from the channel")
        .default_member_permissions(Permissions::MANAGE_MESSAGES)
        .create_option(|option| {
            option
                .name("amount")
                .description("Number of messages to clear (1-100)")
                .kind(serenity::model::application::command::CommandOptionType::Integer)
                .min_int_value(1)
                .max_int_value(100)
                .required(true)
        })
}

pub async fn run(ctx: &Context, command: &serenity::model::application::interaction::application_command::ApplicationCommandInteraction) -> CommandResult {
    // Check if this is a guild
    let guild_id = command.guild_id.ok_or_else(|| BotError::Command(ERROR_GUILD_ONLY.to_string()))?;
    
    // Check user permissions
    let has_permission = check_permission(ctx, command, Permissions::MANAGE_MESSAGES).await?;
    if !has_permission {
        return Err(BotError::Command(ERROR_NO_PERMISSION.to_string()));
    }
    
    // Check bot permissions
    let bot_has_permission = check_bot_permission(ctx, command, Permissions::MANAGE_MESSAGES).await?;
    if !bot_has_permission {
        return Err(BotError::Command("I need manage messages permission to do this!".to_string()));
    }
    
    let options = &command.data.options;
    let amount = super::get_integer_option(options, "amount")
        .ok_or_else(|| BotError::Command("Amount is required".to_string()))? as u64;
    
    let channel_id = command.channel_id;
    
    // Get messages to delete
    let messages = channel_id
        .messages(&ctx.http, |retriever| retriever.limit(amount))
        .await
        .map_err(|_| BotError::Command("Failed to get messages".to_string()))?;
    
    // Delete messages
    let message_ids: Vec<_> = messages.iter().map(|msg| msg.id).collect();
    
    channel_id
        .delete_messages(&ctx.http, message_ids)
        .await
        .map_err(|_| BotError::Command("Failed to delete messages".to_string()))?;
    
    Ok(format!("✅ Successfully cleared {} messages", amount))
}