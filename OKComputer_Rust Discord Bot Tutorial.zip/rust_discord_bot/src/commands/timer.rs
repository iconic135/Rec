use crate::commands::CommandResult;
use crate::error::BotError;
use serenity::builder::CreateApplicationCommand;
use serenity::model::application::interaction::application_command::CommandDataOption;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("timer")
        .description("Set a timer")
        .create_option(|option| {
            option
                .name("seconds")
                .description("Timer duration in seconds")
                .kind(serenity::model::application::command::CommandOptionType::Integer)
                .min_int_value(1)
                .max_int_value(3600) // 1 hour max
                .required(true)
        })
        .create_option(|option| {
            option
                .name("message")
                .description("Timer message (optional)")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(false)
        })
}

pub async fn run(options: &[CommandDataOption]) -> CommandResult {
    let seconds = super::get_integer_option(options, "seconds")
        .ok_or_else(|| BotError::Command("Seconds is required".to_string()))? as u64;
    
    let message = super::get_string_option(options, "message");
    
    if seconds == 0 {
        return Err(BotError::Command("Seconds must be greater than 0".to_string()));
    }
    
    if seconds > 3600 {
        return Err(BotError::Command("Timer cannot be longer than 1 hour".to_string()));
    }
    
    // In a real implementation, you would:
    // 1. Store the timer in a database
    // 2. Start a background task to wait and then send a notification
    // 3. Handle timer cancellation
    
    // For now, we'll just acknowledge the timer
    let timer_msg = message.as_deref().unwrap_or("Timer completed!");
    
    let minutes = seconds / 60;
    let remaining_seconds = seconds % 60;
    
    let mut time_display = String::new();
    if minutes > 0 {
        time_display.push_str(&format!("{} minute(s) ", minutes));
    }
    if remaining_seconds > 0 {
        time_display.push_str(&format!("{} second(s)", remaining_seconds));
    }
    
    Ok(format!(
        "⏱️ **Timer Set**\n\n**Duration:** {}\n**Message:** {}\n\n💡 Note: This is a demo implementation. In a full bot, you'd receive a notification when the timer goes off.",
        time_display.trim(), timer_msg
    ))
}