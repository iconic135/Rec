use crate::commands::CommandResult;
use crate::error::BotError;
use serenity::builder::CreateApplicationCommand;
use serenity::client::Context;
use serenity::model::application::interaction::application_command::CommandDataOption;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("avatar")
        .description("Get a user's avatar")
        .create_option(|option| {
            option
                .name("user")
                .description("The user whose avatar to get (defaults to you)")
                .kind(serenity::model::application::command::CommandOptionType::User)
                .required(false)
        })
}

pub async fn run(ctx: &Context, options: &[CommandDataOption]) -> CommandResult {
    let user_id = super::get_user_option(options, "user");
    let target_user_id = user_id.unwrap_or_else(|| ctx.cache.current_user_id());

    let user = ctx
        .cache
        .user(target_user_id)
        .ok_or_else(|| BotError::Command("User not found".to_string()))?;

    let mut response = String::new();
    
    // User mention
    response.push_str(&format!("🖼️ **Avatar for {}**\n\n", user.name));
    
    // Avatar URL
    if let Some(avatar_url) = user.avatar_url() {
        response.push_str(&avatar_url);
    } else {
        // Fallback to default avatar
        let default_avatar = format!("https://cdn.discordapp.com/embed/avatars/{}.png", user.discriminator % 5);
        response.push_str(&default_avatar);
    }

    Ok(response)
}