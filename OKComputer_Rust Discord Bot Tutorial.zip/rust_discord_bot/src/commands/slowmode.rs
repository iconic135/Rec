use crate::commands::{check_bot_permission, check_permission, CommandResult, ERROR_GUILD_ONLY, ERROR_NO_PERMISSION};
use crate::error::BotError;
use serenity::builder::CreateApplicationCommand;
use serenity::client::Context;
use serenity::model::application::interaction::application_command::CommandDataOption;
use serenity::model::permissions::Permissions;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("slowmode")
        .description("Set slowmode for the channel")
        .default_member_permissions(Permissions::MANAGE_CHANNELS)
        .create_option(|option| {
            option
                .name("seconds")
                .description("Slowmode duration in seconds (0 to disable)")
                .kind(serenity::model::application::command::CommandOptionType::Integer)
                .min_int_value(0)
                .max_int_value(21600) // 6 hours max
                .required(true)
        })
}

pub async fn run(ctx: &Context, command: &serenity::model::application::interaction::application_command::ApplicationCommandInteraction) -> CommandResult {
    // Check if this is a guild
    let guild_id = command.guild_id.ok_or_else(|| BotError::Command(ERROR_GUILD_ONLY.to_string()))?;
    
    // Check user permissions
    let has_permission = check_permission(ctx, command, Permissions::MANAGE_CHANNELS).await?;
    if !has_permission {
        return Err(BotError::Command(ERROR_NO_PERMISSION.to_string()));
    }
    
    // Check bot permissions
    let bot_has_permission = check_bot_permission(ctx, command, Permissions::MANAGE_CHANNELS).await?;
    if !bot_has_permission {
        return Err(BotError::Command("I need manage channels permission to do this!".to_string()));
    }
    
    let options = &command.data.options;
    let seconds = super::get_integer_option(options, "seconds")
        .ok_or_else(|| BotError::Command("Seconds is required".to_string()))? as u64;
    
    let channel_id = command.channel_id;
    
    // Edit the channel to set slowmode
    channel_id
        .edit(&ctx.http, |edit| edit.rate_limit_per_user(seconds))
        .await
        .map_err(|_| BotError::Command("Failed to set slowmode".to_string()))?;
    
    if seconds == 0 {
        Ok("✅ Slowmode disabled for this channel".to_string())
    } else {
        Ok(format!("✅ Slowmode set to {} seconds for this channel", seconds))
    }
}