use crate::commands::{check_bot_permission, check_permission, CommandResult, ERROR_GUILD_ONLY, ERROR_NO_PERMISSION};
use crate::error::BotError;
use serenity::builder::CreateApplicationCommand;
use serenity::client::Context;
use serenity::model::application::interaction::application_command::CommandDataOption;
use serenity::model::permissions::Permissions;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("kick")
        .description("Kick a user from the server")
        .default_member_permissions(Permissions::KICK_MEMBERS)
        .create_option(|option| {
            option
                .name("user")
                .description("The user to kick")
                .kind(serenity::model::application::command::CommandOptionType::User)
                .required(true)
        })
        .create_option(|option| {
            option
                .name("reason")
                .description("Reason for kicking")
                .kind(serenity::model::application::command::CommandOptionType::String)
                .required(false)
        })
}

pub async fn run(ctx: &Context, command: &serenity::model::application::interaction::application_command::ApplicationCommandInteraction) -> CommandResult {
    // Check if this is a guild
    let guild_id = command.guild_id.ok_or_else(|| BotError::Command(ERROR_GUILD_ONLY.to_string()))?;
    
    // Check user permissions
    let has_permission = check_permission(ctx, command, Permissions::KICK_MEMBERS).await?;
    if !has_permission {
        return Err(BotError::Command(ERROR_NO_PERMISSION.to_string()));
    }
    
    // Check bot permissions
    let bot_has_permission = check_bot_permission(ctx, command, Permissions::KICK_MEMBERS).await?;
    if !bot_has_permission {
        return Err(BotError::Command("I need kick permissions to do this!".to_string()));
    }
    
    let options = &command.data.options;
    let user_id = super::get_user_option(options, "user")
        .ok_or_else(|| BotError::Command("User is required".to_string()))?;
    
    let reason = super::get_string_option(options, "reason");
    
    // Get the member to kick
    let member = guild_id
        .member(&ctx.http, user_id)
        .await
        .map_err(|_| BotError::Command("Failed to get member info".to_string()))?;
    
    // Check if the bot can kick this user (they must be lower in hierarchy)
    let bot_member = guild_id
        .member(&ctx.http, ctx.cache.current_user_id())
        .await
        .map_err(|_| BotError::Command("Failed to get bot member info".to_string()))?;
    
    if member.highest_role_info(&ctx.cache).unwrap_or((serenity::model::id::RoleId::from(0), 0)).1 
        >= bot_member.highest_role_info(&ctx.cache).unwrap_or((serenity::model::id::RoleId::from(0), 0)).1 {
        return Err(BotError::Command("I cannot kick this user - they have equal or higher role position!".to_string()));
    }
    
    // Kick the user
    let kick_reason = reason.as_deref().unwrap_or("No reason provided");
    
    guild_id
        .kick_with_reason(&ctx.http, user_id, kick_reason)
        .await
        .map_err(|_| BotError::Command("Failed to kick user".to_string()))?;
    
    Ok(format!("✅ Successfully kicked {} for: {}", member.user.name, kick_reason))
}