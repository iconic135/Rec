use crate::commands::{check_bot_permission, check_permission, CommandResult, ERROR_GUILD_ONLY, ERROR_NO_PERMISSION};
use crate::error::BotError;
use serenity::builder::CreateApplicationCommand;
use serenity::client::Context;
use serenity::model::application::interaction::application_command::CommandDataOption;
use serenity::model::permissions::Permissions;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("unmute")
        .description("Unmute a user")
        .default_member_permissions(Permissions::MODERATE_MEMBERS)
        .create_option(|option| {
            option
                .name("user")
                .description("The user to unmute")
                .kind(serenity::model::application::command::CommandOptionType::User)
                .required(true)
        })
}

pub async fn run(ctx: &Context, command: &serenity::model::application::interaction::application_command::ApplicationCommandInteraction) -> CommandResult {
    // Check if this is a guild
    let guild_id = command.guild_id.ok_or_else(|| BotError::Command(ERROR_GUILD_ONLY.to_string()))?;
    
    // Check user permissions
    let has_permission = check_permission(ctx, command, Permissions::MODERATE_MEMBERS).await?;
    if !has_permission {
        return Err(BotError::Command(ERROR_NO_PERMISSION.to_string()));
    }
    
    // Check bot permissions
    let bot_has_permission = check_bot_permission(ctx, command, Permissions::MODERATE_MEMBERS).await?;
    if !bot_has_permission {
        return Err(BotError::Command("I need timeout permissions to do this!".to_string()));
    }
    
    let options = &command.data.options;
    let user_id = super::get_user_option(options, "user")
        .ok_or_else(|| BotError::Command("User is required".to_string()))?;
    
    // Get the member
    let member = guild_id
        .member(&ctx.http, user_id)
        .await
        .map_err(|_| BotError::Command("Failed to get member info".to_string()))?;
    
    // Unmute the user (remove timeout)
    member
        .enable_communication(&ctx.http)
        .await
        .map_err(|_| BotError::Command("Failed to unmute user".to_string()))?;
    
    Ok(format!("🔊 Successfully unmuted {}", member.user.name))
}