use crate::commands::CommandResult;
use crate::error::BotError;
use serenity::builder::CreateApplicationCommand;
use serenity::client::Context;
use serenity::model::application::interaction::application_command::CommandDataOption;
use serenity::model::id::UserId;

pub fn register(command: &mut CreateApplicationCommand) -> &mut CreateApplicationCommand {
    command
        .name("userinfo")
        .description("Get information about a user")
        .create_option(|option| {
            option
                .name("user")
                .description("The user to get info about (defaults to you)")
                .kind(serenity::model::application::command::CommandOptionType::User)
                .required(false)
        })
}

pub async fn run(ctx: &Context, options: &[CommandDataOption]) -> CommandResult {
    let user_id = super::get_user_option(options, "user");
    let target_user_id = user_id.unwrap_or_else(|| ctx.cache.current_user_id());

    let user = if let Some(guild_id) = ctx.cache.guilds().first() {
        guild_id
            .member(&ctx.http, target_user_id)
            .await
            .map_err(|_| BotError::Command("Failed to get member info".to_string()))?
    } else {
        return Err(BotError::Command("This command can only be used in a server".to_string()));
    };

    let mut response = String::new();
    
    // User name and mention
    response.push_str(&format!("👤 **User:** {}\n", user.user.name));
    response.push_str(&format!("🆔 **ID:** {}\n", user.user.id));
    
    // Account creation date
    let created_at = user.user.created_at().format("%B %d, %Y at %H:%M UTC");
    response.push_str(&format!("📅 **Account Created:** {}\n", created_at));
    
    // Join date if available
    if let Some(joined_at) = user.joined_at {
        let joined_date = joined_at.format("%B %d, %Y at %H:%M UTC");
        response.push_str(&format!("🚪 **Joined Server:** {}\n", joined_date));
    }
    
    // Roles
    if !user.roles.is_empty() {
        let role_mentions: Vec<String> = user.roles.iter().map(|role_id| format!("<@&{}>", role_id)).collect();
        response.push_str(&format!("🎭 **Roles:** {}\n", role_mentions.join(", ")));
    }
    
    // Status
    if let Some(presence) = user.presence {
        response.push_str(&format!("📊 **Status:** {:?}\n", presence.status));
    }
    
    // Bot indicator
    if user.user.bot {
        response.push_str("🤖 **Bot Account:** Yes\n");
    }
    
    // Avatar
    if let Some(avatar_url) = user.user.avatar_url() {
        response.push_str(&format!("\n🖼️ **Avatar:** {}\n", avatar_url));
    }

    Ok(response)
}