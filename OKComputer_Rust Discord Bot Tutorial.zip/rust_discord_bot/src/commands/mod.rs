pub mod avatar;
pub mod ban;
pub mod cat;
pub mod choose;
pub mod clear;
pub mod dog;
pub mod embed;
pub mod help;
pub mod info;
pub mod kick;
pub mod meme;
pub mod mute;
pub mod ping;
pub mod poll;
pub mod reminder;
pub mod roll;
pub mod say;
pub mod serverinfo;
pub mod slowmode;
pub mod timer;
pub mod unmute;
pub mod userinfo;
pub mod weather;

use crate::error::BotResult;
use serenity::builder::CreateApplicationCommand;
use serenity::model::application::interaction::application_command::CommandDataOption;

type CommandResult = BotResult<String>;

// Helper function to get string option
fn get_string_option(options: &[CommandDataOption], name: &str) -> Option<String> {
    options
        .iter()
        .find(|option| option.name == name)
        .and_then(|option| option.value.as_ref())
        .and_then(|value| value.as_str())
        .map(String::from)
}

// Helper function to get integer option
fn get_integer_option(options: &[CommandDataOption], name: &str) -> Option<i64> {
    options
        .iter()
        .find(|option| option.name == name)
        .and_then(|option| option.value.as_ref())
        .and_then(|value| value.as_i64())
}

// Helper function to get boolean option
fn get_boolean_option(options: &[CommandDataOption], name: &str) -> Option<bool> {
    options
        .iter()
        .find(|option| option.name == name)
        .and_then(|option| option.value.as_ref())
        .and_then(|value| value.as_bool())
}

// Helper function to get user option
fn get_user_option(options: &[CommandDataOption], name: &str) -> Option<serenity::model::id::UserId> {
    options
        .iter()
        .find(|option| option.name == name)
        .and_then(|option| option.value.as_ref())
        .and_then(|value| value.as_str())
        .and_then(|s| s.parse::<u64>().ok())
        .map(serenity::model::id::UserId::from)
}

// Helper function to get channel option
fn get_channel_option(
    options: &[CommandDataOption],
    name: &str,
) -> Option<serenity::model::id::ChannelId> {
    options
        .iter()
        .find(|option| option.name == name)
        .and_then(|option| option.value.as_ref())
        .and_then(|value| value.as_str())
        .and_then(|s| s.parse::<u64>().ok())
        .map(serenity::model::id::ChannelId::from)
}

// Common error messages
const ERROR_NO_PERMISSION: &str = "You don't have permission to use this command!";
const ERROR_GUILD_ONLY: &str = "This command can only be used in a server!";
const ERROR_BOT_MISSING_PERMISSIONS: &str = "I don't have the required permissions!";
const ERROR_INVALID_ARGUMENT: &str = "Invalid argument provided!";

// Permission check helper
async fn check_permission(
    ctx: &serenity::client::Context,
    command: &serenity::model::application::interaction::application_command::ApplicationCommandInteraction,
    permission: serenity::model::permissions::Permissions,
) -> BotResult<bool> {
    let guild = command
        .guild_id
        .ok_or_else(|| crate::error::BotError::Command(ERROR_GUILD_ONLY.to_string()))?;

    let member = guild
        .member(&ctx.http, command.user.id)
        .await
        .map_err(|_| crate::error::BotError::Command("Failed to get member info".to_string()))?;

    let permissions = member
        .permissions(&ctx.cache)
        .ok_or_else(|| crate::error::BotError::Command("Failed to get permissions".to_string()))?;

    Ok(permissions.contains(permission))
}

// Bot permission check helper
async fn check_bot_permission(
    ctx: &serenity::client::Context,
    command: &serenity::model::application::interaction::application_command::ApplicationCommandInteraction,
    permission: serenity::model::permissions::Permissions,
) -> BotResult<bool> {
    let guild = command
        .guild_id
        .ok_or_else(|| crate::error::BotError::Command(ERROR_GUILD_ONLY.to_string()))?;

    let bot_member = guild
        .member(&ctx.http, ctx.cache.current_user_id())
        .await
        .map_err(|_| crate::error::BotError::Command("Failed to get bot member info".to_string()))?;

    let permissions = bot_member
        .permissions(&ctx.cache)
        .ok_or_else(|| crate::error::BotError::Command("Failed to get bot permissions".to_string()))?;

    Ok(permissions.contains(permission))
}