use crate::error::BotResult;

// Utility functions for the bot

pub fn format_duration(seconds: u64) -> String {
    let hours = seconds / 3600;
    let minutes = (seconds % 3600) / 60;
    let secs = seconds % 60;
    
    let mut parts = Vec::new();
    
    if hours > 0 {
        parts.push(format!("{}h", hours));
    }
    if minutes > 0 {
        parts.push(format!("{}m", minutes));
    }
    if secs > 0 || parts.is_empty() {
        parts.push(format!("{}s", secs));
    }
    
    parts.join(" ")
}

pub fn parse_mention(mention: &str) -> Option<u64> {
    if mention.starts_with("<@") && mention.ends_with(">") {
        let id_str = mention.trim_start_matches("<@").trim_end_matches(">");
        if id_str.starts_with("!") {
            id_str[1..].parse().ok()
        } else {
            id_str.parse().ok()
        }
    } else {
        mention.parse().ok()
    }
}

pub fn is_valid_url(url: &str) -> bool {
    url::Url::parse(url).is_ok()
}

pub fn truncate_string(s: &str, max_chars: usize) -> String {
    if s.len() <= max_chars {
        s.to_string()
    } else {
        format!("{}...", &s[..max_chars - 3])
    }
}

pub fn sanitize_input(input: &str) -> String {
    // Remove potentially harmful characters
    input.replace('`', "\\`").replace('*', "\\*").replace('_', "\\_")
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_format_duration() {
        assert_eq!(format_duration(0), "0s");
        assert_eq!(format_duration(30), "30s");
        assert_eq!(format_duration(60), "1m");
        assert_eq!(format_duration(90), "1m 30s");
        assert_eq!(format_duration(3600), "1h");
        assert_eq!(format_duration(3661), "1h 1m 1s");
    }
    
    #[test]
    fn test_parse_mention() {
        assert_eq!(parse_mention("<@123456789>"), Some(123456789));
        assert_eq!(parse_mention("<@!123456789>"), Some(123456789));
        assert_eq!(parse_mention("123456789"), Some(123456789));
        assert_eq!(parse_mention("invalid"), None);
    }
    
    #[test]
    fn test_truncate_string() {
        assert_eq!(truncate_string("Hello", 10), "Hello");
        assert_eq!(truncate_string("Hello World", 8), "Hello...");
        assert_eq!(truncate_string("Hello", 3), "...");
    }
}