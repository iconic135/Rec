use anyhow::Result;
use clap::Parser;
use dotenv::dotenv;
use serenity::prelude::*;
use std::env;
use tracing::{error, info};
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

mod commands;
mod config;
mod database;
mod error;
mod events;
mod utils;

use config::Config;
use events::Handler;

#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Args {
    #[arg(short, long, default_value = ".env")]
    config: String,
}

#[tokio::main]
async fn main() -> Result<()> {
    // Load environment variables
    dotenv().ok();
    
    // Parse command line arguments
    let args = Args::parse();
    
    // Initialize tracing
    tracing_subscriber::registry()
        .with(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "discord_bot=info,serenity=warn".into()),
        )
        .with(tracing_subscriber::fmt::layer())
        .init();

    info!("Starting Discord Bot...");

    // Load configuration
    let config = Config::load(&args.config)?;
    
    // Initialize database if enabled
    #[cfg(feature = "database")]
    {
        database::init(&config.database_url).await?;
        info!("Database initialized");
    }

    // Create bot intents
    let intents = GatewayIntents::GUILDS
        | GatewayIntents::GUILD_MESSAGES
        | GatewayIntents::MESSAGE_CONTENT
        | GatewayIntents::GUILD_VOICE_STATES
        | GatewayIntents::GUILD_MESSAGE_REACTIONS
        | GatewayIntents::GUILD_MEMBERS;

    // Create the client
    let mut client = Client::builder(&config.discord_token, intents)
        .event_handler(Handler::new(config.clone()))
        .application_id(config.application_id)
        .await
        .expect("Error creating client");

    // Start the bot
    info!("Bot is starting...");
    if let Err(why) = client.start().await {
        error!("Client error: {:?}", why);
    }

    Ok(())
}