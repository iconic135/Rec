use crate::commands;
use crate::config::Config;
use serenity::async_trait;
use serenity::client::{Context, EventHandler};
use serenity::model::application::command::Command;
use serenity::model::application::interaction::{Interaction, InteractionResponseType};
use serenity::model::gateway::Ready;
use serenity::model::id::GuildId;
use serenity::model::prelude::{Guild, Member, Message, Reaction, VoiceState};
use tracing::{error, info, warn};

pub struct Handler {
    config: Config,
}

impl Handler {
    pub fn new(config: Config) -> Self {
        Self { config }
    }
}

#[async_trait]
impl EventHandler for Handler {
    async fn ready(&self, ctx: Context, ready: Ready) {
        info!("{} is connected!", ready.user.name);

        // Register slash commands globally
        let commands = Command::set_global_application_commands(&ctx.http, |commands| {
            commands
                .create_application_command(|command| commands::ping::register(command))
                .create_application_command(|command| commands::info::register(command))
                .create_application_command(|command| commands::help::register(command))
                .create_application_command(|command| commands::userinfo::register(command))
                .create_application_command(|command| commands::serverinfo::register(command))
                .create_application_command(|command| commands::avatar::register(command))
                .create_application_command(|command| commands::roll::register(command))
                .create_application_command(|command| commands::choose::register(command))
                .create_application_command(|command| commands::poll::register(command))
                .create_application_command(|command| commands::kick::register(command))
                .create_application_command(|command| commands::ban::register(command))
                .create_application_command(|command| commands::clear::register(command))
                .create_application_command(|command| commands::slowmode::register(command))
                .create_application_command(|command| commands::mute::register(command))
                .create_application_command(|command| commands::unmute::register(command))
                .create_application_command(|command| commands::weather::register(command))
                .create_application_command(|command| commands::cat::register(command))
                .create_application_command(|command| commands::dog::register(command))
                .create_application_command(|command| commands::meme::register(command))
                .create_application_command(|command| commands::reminder::register(command))
                .create_application_command(|command| commands::timer::register(command))
                .create_application_command(|command| commands::embed::register(command))
                .create_application_command(|command| commands::say::register(command))
        })
        .await;

        match commands {
            Ok(commands) => {
                info!("Successfully registered {} global commands", commands.len());
            }
            Err(e) => {
                error!("Failed to register global commands: {:?}", e);
            }
        }
    }

    async fn interaction_create(&self, ctx: Context, interaction: Interaction) {
        if let Interaction::ApplicationCommand(command) = interaction {
            let response_content = match command.data.name.as_str() {
                "ping" => commands::ping::run(&command.data.options),
                "info" => commands::info::run(&command.data.options),
                "help" => commands::help::run(&command.data.options),
                "userinfo" => commands::userinfo::run(&ctx, &command.data.options).await,
                "serverinfo" => commands::serverinfo::run(&ctx, &command.data.options).await,
                "avatar" => commands::avatar::run(&ctx, &command.data.options).await,
                "roll" => commands::roll::run(&command.data.options),
                "choose" => commands::choose::run(&command.data.options),
                "poll" => commands::poll::run(&command.data.options),
                "kick" => commands::kick::run(&ctx, &command).await,
                "ban" => commands::ban::run(&ctx, &command).await,
                "clear" => commands::clear::run(&ctx, &command).await,
                "slowmode" => commands::slowmode::run(&ctx, &command).await,
                "mute" => commands::mute::run(&ctx, &command).await,
                "unmute" => commands::unmute::run(&ctx, &command).await,
                "weather" => commands::weather::run(&command.data.options).await,
                "cat" => commands::cat::run().await,
                "dog" => commands::dog::run().await,
                "meme" => commands::meme::run().await,
                "reminder" => commands::reminder::run(&command.data.options).await,
                "timer" => commands::timer::run(&command.data.options).await,
                "embed" => commands::embed::run(&command.data.options),
                "say" => commands::say::run(&command.data.options),
                _ => Err("Unknown command".into()),
            };

            match response_content {
                Ok(content) => {
                    if let Err(e) = command
                        .create_interaction_response(&ctx.http, |response| {
                            response
                                .kind(InteractionResponseType::ChannelMessageWithSource)
                                .interaction_response_data(|message| message.content(content))
                        })
                        .await
                    {
                        error!("Failed to send response: {:?}", e);
                    }
                }
                Err(e) => {
                    warn!("Command error: {:?}", e);
                    if let Err(e) = command
                        .create_interaction_response(&ctx.http, |response| {
                            response
                                .kind(InteractionResponseType::ChannelMessageWithSource)
                                .interaction_response_data(|message| {
                                    message
                                        .content(format!("❌ Error: {}", e))
                                        .ephemeral(true)
                                })
                        })
                        .await
                    {
                        error!("Failed to send error response: {:?}", e);
                    }
                }
            }
        }
    }

    async fn message(&self, ctx: Context, msg: Message) {
        // Ignore bot messages
        if msg.author.bot {
            return;
        }

        // Traditional prefix commands (fallback)
        if msg.content.starts_with(&self.config.bot_prefix) {
            let content = msg.content.trim_start_matches(&self.config.bot_prefix);
            let parts: Vec<&str> = content.split_whitespace().collect();
            
            if parts.is_empty() {
                return;
            }

            match parts[0] {
                "ping" => {
                    let _ = msg
                        .channel_id
                        .say(&ctx.http, "Pong!")
                        .await;
                }
                _ => {}
            }
        }
    }

    async fn guild_create(&self, ctx: Context, guild: Guild, _is_new: bool) {
        info!("Joined guild: {} ({})