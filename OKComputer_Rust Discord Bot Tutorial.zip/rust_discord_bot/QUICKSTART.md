# Quick Start Guide

Get your Discord bot up and running in 5 minutes!

## ⚡ Step 1: Get Discord Bot Credentials

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Click "New Application"
3. Give it a name (e.g., "My Rust Bot")
4. Go to "Bot" section on the left
5. Click "Add Bot" and confirm
6. Copy the **Token** (this is your `DISCORD_TOKEN`)
7. Go to "OAuth2" section
8. Copy the **Application ID** (this is your `APPLICATION_ID`)

## ⚡ Step 2: Configure the Bot

1. Copy the environment template:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` file:
   ```
   DISCORD_TOKEN=your_bot_token_here
   APPLICATION_ID=your_application_id_here
   RUST_LOG=info
   ```

   Replace `your_bot_token_here` and `your_application_id_here` with your actual values.

## ⚡ Step 3: Build and Run

1. **Build the bot:**
   ```bash
   chmod +x build.sh
   ./build.sh
   ```

   Or manually:
   ```bash
   cargo build --release
   ```

2. **Run the bot:**
   ```bash
   ./target/release/discord_bot
   ```

3. **Test the bot:**
   - Invite the bot to your server (use OAuth2 URL generator in Discord Developer Portal)
   - Type `/ping` in your Discord server
   - You should see "🏓 Pong! Bot is responding normally."

## ⚡ Step 4: Add More Features (Optional)

### Weather Command
To use the weather command, get a free API key from [OpenWeatherMap](https://openweathermap.org/api):
1. Sign up for a free account
2. Get your API key from your dashboard
3. Add to your `.env` file:
   ```
   WEATHER_API_KEY=your_openweathermap_api_key
   ```

### Database Support
For persistent storage (reminders, settings, etc.):
1. Make sure the `database` feature is enabled in `Cargo.toml` (it is by default)
2. The bot will automatically create and manage the SQLite database

## 🎯 Common Commands

### Basic Commands
- `/ping` - Check if bot is working
- `/help` - See all available commands
- `/info` - Get bot information

### Fun Commands
- `/roll 2d20` - Roll 2 dice with 20 sides
- `/choose pizza, burger, salad` - Randomly choose an option
- `/cat` - Get a random cat picture
- `/dog` - Get a random dog picture
- `/meme` - Get a random meme

### Utility Commands
- `/userinfo @username` - Get user information
- `/serverinfo` - Get server information
- `/avatar @username` - Get user's avatar

### Moderation Commands (Admin only)
- `/kick @username reason` - Kick a user
- `/ban @username reason` - Ban a user
- `/clear 10` - Clear 10 messages
- `/slowmode 5` - Set 5-second slowmode

## 🚀 Next Steps

1. **Invite the bot to more servers**
2. **Customize commands** in `src/commands/`
3. **Add new features** following the existing patterns
4. **Deploy to production** using the [Deployment Guide](DEPLOYMENT.md)
5. **Monitor logs** to ensure everything works

## ❓ Troubleshooting

### "Invalid token" error
- Make sure your `DISCORD_TOKEN` is correct
- The token should be from the "Bot" section, not "OAuth2"

### "Application ID" error
- Make sure your `APPLICATION_ID` is correct
- This should be a number from the "OAuth2" section

### Commands not appearing
- It can take up to 1 hour for global commands to appear
- Try restarting the bot
- Check the bot has necessary permissions in your server

### Permission errors
- Make sure the bot has Administrator permissions or specific permissions needed for commands
- Check the bot role is high enough in the role hierarchy

## 📚 Need More Help?

- Check the full [README.md](README.md)
- Read the [Deployment Guide](DEPLOYMENT.md)
- Look at the [source code](src/) for examples
- Check [Serenity documentation](https://docs.rs/serenity)

## 🎉 You're Done!

Your Discord bot should now be running and responding to commands. Have fun customizing it!