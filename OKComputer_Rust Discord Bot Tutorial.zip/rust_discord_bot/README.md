# Discord Bot in Rust

A comprehensive, feature-rich Discord bot built with Rust using the Serenity framework.

## 🌟 Features

### ✅ Implemented Commands

#### Utility Commands
- `/ping` - Check bot latency and response time
- `/info` - Get information about the bot
- `/help` - Get help and see all available commands
- `/userinfo` - Get information about a user
- `/serverinfo` - Get information about the server
- `/avatar` - Get a user's avatar

#### Fun Commands
- `/roll` - Roll dice with configurable sides and count
- `/choose` - Randomly choose from given options
- `/poll` - Create a poll with up to 5 options
- `/cat` - Get a random cat picture
- `/dog` - Get a random dog picture
- `/meme` - Get a random meme

#### Moderation Commands
- `/kick` - Kick a user from the server
- `/ban` - Ban a user from the server
- `/clear` - Clear messages from the channel
- `/slowmode` - Set slowmode for the channel
- `/mute` - Mute a user (timeout)
- `/unmute` - Unmute a user

#### Tools & API Commands
- `/weather` - Get current weather for a city (requires API key)
- `/reminder` - Set a reminder
- `/timer` - Set a timer
- `/embed` - Create a custom embed message
- `/say` - Make the bot say something

### 🏗️ Architecture

- **Framework**: Serenity (Discord bot framework)
- **Async Runtime**: Tokio
- **Error Handling**: anyhow + thiserror
- **Logging**: tracing
- **Database**: SQLite (optional, via SQLx)
- **HTTP Client**: reqwest

### 🛠️ Configuration

1. Copy `.env.example` to `.env`
2. Fill in your Discord bot token and application ID
3. (Optional) Set up a weather API key from [OpenWeatherMap](https://openweathermap.org/api)

### 📦 Installation

```bash
# Clone the repository
git clone <repository-url>
cd rust_discord_bot

# Copy environment template
cp .env.example .env
# Edit .env with your bot token

# Build the bot
cargo build --release

# Run the bot
cargo run --release
```

### 🚀 Deployment

#### Using Cargo
```bash
cargo run --release
```

#### Using Docker (future enhancement)
```bash
docker build -t discord-bot .
docker run -d --name discord-bot --env-file .env discord-bot
```

### 🔧 Development

#### Running in development mode
```bash
cargo run
```

#### Running with debug logging
```bash
RUST_LOG=debug cargo run
```

#### Running with database support
```bash
cargo run --features database
```

### 🧪 Testing

```bash
cargo test
```

### 📋 Requirements

- Rust 1.70+ (with Cargo)
- Discord Bot Token
- Discord Application ID

### 🔐 Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DISCORD_TOKEN` | Your Discord bot token | ✅ Yes |
| `APPLICATION_ID` | Your Discord application ID | ✅ Yes |
| `DATABASE_URL` | Database connection string | ❌ No |
| `RUST_LOG` | Logging level (info, debug, trace) | ❌ No |
| `BOT_PREFIX` | Traditional command prefix | ❌ No |
| `WEATHER_API_KEY` | OpenWeatherMap API key | ❌ No |

### 🎨 Project Structure

```
src/
├── main.rs          # Entry point and bot initialization
├── config.rs        # Configuration management
├── error.rs         # Error types and handling
├── events.rs        # Event handlers
├── database.rs      # Database operations (optional)
├── utils.rs         # Utility functions
└── commands/        # Command implementations
    ├── mod.rs       # Command module
    ├── ping.rs      # Ping command
    ├── info.rs      # Info command
    ├── help.rs      # Help command
    └── ...          # Other commands
```

### 🔮 Future Enhancements

- [ ] Music playback (voice channel support)
- [ ] Database-backed settings and reminders
- [ ] Auto-moderation features
- [ ] Welcome messages and leave messages
- [ ] Leveling system
- [ ] Economy system
- [ ] Custom commands
- [ ] Web dashboard
- [ ] Docker support
- [ ] Unit tests for all commands
- [ ] Integration tests
- [ ] CI/CD pipeline

### 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

### 🔗 Links

- [Discord Developer Portal](https://discord.com/developers/applications)
- [Serenity Documentation](https://docs.rs/serenity)
- [Rust Documentation](https://doc.rust-lang.org/)

### 💡 Tips

- Make sure your bot has the necessary permissions in your Discord server
- Use slash commands for better user experience
- Test commands in a private server before deploying to production
- Keep your bot token secure and never share it publicly
- Consider using a process manager like systemd or PM2 for production deployment

### 🆘 Support

If you encounter any issues or have questions, feel free to open an issue in the repository.

---

**Made with ❤️ and Rust**